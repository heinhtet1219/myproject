<?php
error_reporting(1);
session_start();
$i=$_REQUEST['buy_pro'];
$_SESSION['sid']=$_POST['id'];
include("connection.php");
if($_POST['ord'])
{
$cate=$_POST['cate']; 
$prodno=$_POST['prodno'];
$price=$_POST['price'];
$name=$_POST['nam'];
$phone=$_POST['pho'];
$add=$_POST['add'];
$ordno=rand(111,999);
if($qry="INSERT INTO order(category,product_name,price,name,phone,address,ord_no) values('$cate','$prodno','$price','$name','$phone','$add','$ordno')")
{
//echo "<script>location.href='ordersent.php?prod'</script>";
header("location:ordersuccess.php?order_no=$ordno");  }
else {$error= "user already exists";}}

if($_POST['Cancel'])
{
    header("location:index.php");
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="code/bootstrap.min.css">
    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/6041b3011b.js" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
</head>
<body>
    <div class="menucontainer">
        <div class="logocontainer">
            <img src="img/brand logo.png" alt="" width="160%" >
        </div>
        <div class="menubox">
            <a href="index.php" class="menu">Home</a>
            <a href="register.php" class="menu">Register</a>
            <a href="feedback.php" class="menu">Feedback</a>
        </div>
        <div class="menubar"><i class="fa-solid fa-bars"></i></div>
    </div><!--End Header-->
        


    <div class="registerContainer ord">
        <div class="registerBox">
            <div class="registerHeader">Order Form</div>
        <?php
			include("connection.php");
			$sel=mysql_query("select * from product where id='$i' ");
			$mat=mysql_fetch_array($sel);
			
			
			?>
            <form  method="post">
				
                <label>Category : </label><br>
                <input type="text" name="cate" id="cate" readonly value="<?php echo $mat['category'];?>" class="input_field" >
                <label>Product Name : </label>
                <input type="text" name="prodno" id="prodno" readonly value="<?php echo $mat['product_name'];?>" class="input_field" /><br>
                <label>Price :  </label><br>
                <input type="text" name="price" id="price" readonly value="<?php echo $mat['price'];?>" class="input_field" /><br>
				 <label>Name: </label><br>
                <input type="text" name="nam" id="nam" class="input_field" /><br>
				 <label>Phone </label><br>
                <input type="text" name="pho" id="php" class="input_field" /><br>
				 <label>Address</label><br>
                <textarea id="add" name="add" rows="0" cols="0" class="required"></textarea><br>
				 
                <input type="submit" name="ord" id="ord" value="sent order" class="submit_button" />
				 <input type="submit" name="Cancel" value="Cancel" class="submit_button" />
				
            </form>
            
        
        </div>  
    </div>
    


    <div class="teamcontainer">
        <div class="team">
            Web Developer: Hein Htet, Yangon, Myanmar. 9/10/2023 Unknown Restruarnt.com.
        </div>
    </div>
</body>
</html>