<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="code/bootstrap.min.css">
    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/6041b3011b.js" crossorigin="anonymous"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    
</head>
<body>
    <div class="menucontainer">
        <div class="logocontainer">
            <img src="img/brand logo.png" alt="" width="160%" >
        </div>
        <div class="menubox">
            <a href="index.php" class="menu">Home</a>
            <a href="register.php" class="menu">Register</a>
            <a href="feedback.php" class="menu">Feedback</a>
        </div>
        <div class="menubar"><i class="fa-solid fa-bars"></i></div>
    </div><!--End Header-->


    <div class="registerContainer">
        <div class="registerBox">
            <div class="registerHeader">Register form</div>


                       
            <?php
            error_reporting(1);
            include("connection.php");
            if($_POST['sub'])
            {
                $name = $_POST['t1'];
                $email = $_POST['t2'];
                $password = $_POST['t3'];
                $phone = $_POST['t4'];
                $address = $_POST['t5'];

                if(mysql_query("insert into register(name,email,password,phone,address) values('$name','$email','$password','$phone','$address')"))
                {
                    header ("location:registersuccess.php?name=$name & email=$email");
                }

                else {$error= "user already exists";}

            }
            ?>

            <form method="post">
                <label for="name">Name :</label><br>
                <input type="text" name="t1" id="name" required><br>
                <label for="email">Email :</label><br>
                <input type="email" name="t2" id="email" required><br>
                <label for="pass">Password :</label><br>
                <input type="password" name="t3" id="pass" required><br>
                <label for="phone">Phone :</label><br>
                <input type="text" name="t4" id="phone" required><br>
                <label for="address">Address :</label><br>
                <input type="text" name="t5" id="address" required><br>
                <input class="btn btn-primary" type="submit" value="Register" name="sub" id="sub">
                <input class="btn btn-primary" type="reset" value="Reset">
                <label><?php echo "<font color='red'>$error</font>";?></label>
            </form>
        </div>
    </div>
    


    <div class="teamcontainer">
        <div class="team">
            Web Developer: Hein Htet, Yangon, Myanmar. 9/10/2023 Unknown Restruarnt.com.
        </div>
    </div>
</body>
</html>