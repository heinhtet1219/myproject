<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>
<?php
error_reporting(1);
include("connection.php");
$p_brands = $_POST['p_brands'];
$img=$_FILES['img']['name'];
$prono=$_POST['t1'];
$price=$_POST['t2'];
if($_POST['sub'])
{$qry="INSERT INTO product(category,img,product_name,price)VALUES('$p_brands','$img','$prono','$price')";
$result=mysql_query($qry) or die ("save items query fail.");
if($result)			
	   {mkdir("product_image/$i");
			move_uploaded_file($_FILES['img']['tmp_name'],"product_image/$i".$_FILES['img']['name']);	
  // move_uploaded_file($_FILES['file']['tmp_name'],"itempics/$itemno.jpg");
		
	    $err="<font size='+2'>item inserted successfully</font>";
	
		}
	else
	 {
	   echo "item is not inserted";
	   }
	}  
	mysql_close($con);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="code/bootstrap.min.css">
    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/6041b3011b.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="menucontainer">
        <div class="logocontainer">
            <img src="img/brand logo.png" alt="" width="160%" >
        </div>
        <div class="menubox">
            <a href="home.php" class="menu">Home</a>
            <a href="add_product.php" class="menu">Add Product</a>
            <a href="view_product.php" class="menu">View Product</a>
        </div>
        <div class="menubar"><i class="fa-solid fa-bars"></i></div>
    </div><!--End Header-->
	<div class="registerContainer" >
		<div class="registerBox" >
    <form method="post" name="testform" enctype="multipart/form-data">
			<table border="0" cellpadding="10px" align="center" style="font-size:16px; font-weight:bold;">
				
				<tr>
					<td>Category</td>
					<td>
						<select name="p_brands" required>
							<option>Select Category</option>
							<?php
							$sel=mysql_query("select * from category ");
							while($arr=mysql_fetch_array($sel))
						   {
						   		$i=$arr['ca_id'];
								$i2=$arr['name'];
									
									echo "<option value=$i2>$i2</option>";
								}
							?>
						</select>
					</td>
				</tr>
				<tr>
					<td>Product Name</td>
					<td><input type="text" name="t1" required></td>
				</tr>
				<tr>
					<td>Product Price</td>
					<td><input type="text" name="t2" required></td>
				</tr>
				<tr>
					<td>Product Image</td>
					<td><input type="file" name="img" required></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="sub"  value="Insert Product"></td>
				</tr>
			</table>
		  </form>
		</div>
	</div>
<?php }  ?>


    <div class="teamcontainer">
        <div class="team">
            Web Developer: Hein Htet, Yangon, Myanmar. 9/10/2023 Unknown Restruarnt.com.
        </div>
    </div>
</body>
</html>