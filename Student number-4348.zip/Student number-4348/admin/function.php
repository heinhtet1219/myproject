<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="admin.css">
</head>
<body>
	


<?php
	
	$con = mysqli_connect("localhost","root","","restaurant");

	//getting the brands from brands table.
	function getBrands()
	{
		global $con;
		$get_brand = "SELECT * FROM category";
		$run_brand = mysqli_query($con,$get_brand);
		while($row_brand = mysqli_fetch_array($run_brand))
		{
			$b_id = $row_brand['ca_id'];
			$b_title = $row_brand['name'];
			echo "<li class='menulist'><a class='item' href='index.php?brand=$b_title'>$b_title</a></li>";
			
		}
	}

	//getting the products from product table.
	function getProduct()
	{
	  if(!isset($_GET['brand']))
	  {
		global $con;
		$get_pro = "SELECT * FROM product order by rand()";
		$run_pro = mysqli_query($con,$get_pro);
		while($row_pro = mysqli_fetch_array($run_pro))
		{ 
			$pro_id = $row_pro['id'];
			$pro_brand = $row_pro['category'];
			$pro_image = $row_pro['img'];
			$pro_model = $row_pro['product_name'];
			$pro_price = $row_pro['price'];
			echo " 
					<div style='width: 200px;
						height: 200px;
						display: flex;
						flex-wrap: wrap;
						margin: 10px;
						border: 1px solid black;
						background-color: wheat;'>
					<div style='text-align:center;padding:5px 10px 5px 3px;align-item:center;'>
								<img src='admin/product_image/$pro_image' width='120px' height='100px'><br>
								<div style='font-size: 15px;font-weight: 500;'>$pro_model</div>
								<b> $pro_price </b><br>
								<a href='login.php?buy_pro=$pro_id' ><button> Buy </button> </a>
					</div>
					</div>
			
			
			
			";
			
		}
	  }
	}
	
	function getBrandPro()
	{
	  if(isset($_GET['brand']))
	  {
		global $con;
		$brand_title = $_GET['brand'];
		$get_brand_pro = "SELECT * FROM product WHERE category='$brand_title'";
		$run_brand_pro = mysqli_query($con,$get_brand_pro);
		while($row_brand_pro = mysqli_fetch_array($run_brand_pro))
		{ 
			$pro_id = $row_brand_pro['id'];
			$pro_brand = $row_brand_pro['category'];
			$pro_model = $row_brand_pro['product_name'];
			$pro_price = $row_brand_pro['price'];
			$pro_image = $row_brand_pro['img'];
			echo " 
			
				<div style='width: 200px;
					height: 200px;
					display: flex;
					flex-wrap: wrap;
					margin: 10px;
					border: 1px solid black;
					background-color: white;'>
				<div style='text-align:center;padding-top:5px;padding-left:15px;'>
				<img src='admin/product_image/$pro_image' width='120px' height='100px'><br>
				<div style='font-size: 15px;font-weight: 500;text-align:center;'>$pro_model</div>
				<b> $pro_price </b><br>
				<a href='login.php?buy_pro=$pro_id' ><button> Buy </button> </a>
					</div>
				</div>

			
			
			
			";
			
		}
	  }
	}
	
	
	
?>

</body>
</html>