<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="code/bootstrap.min.css">
    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/6041b3011b.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="menucontainer">
        <div class="logocontainer">
            <img src="img/brand logo.png" alt="" width="160%" >
        </div>
        <div class="menubox">
            <a href="home.php" class="menu">Home</a>
            <a href="add_product.php" class="menu">Add Product</a>
            <a href="view_product.php" class="menu">View Product</a>
        </div>
        <div class="menubar"><i class="fa-solid fa-bars"></i></div>
    </div><!--End Header-->
	<div class="feedContainer" >
		<div class="feedBox" >

	<h2 align="center"> View Product </h2>
    	
       
        <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from product ");
						echo"<form method='post'>
                        <table style='border-color:#000000;background-color:#0000007d; border-style: dotted;margin:0px auto;' width='800px' align='center'>
                        <tr align='center'>
                        <td>Image</td>
                        <td>Product Name</td>
                        <td>Price</td>
                        </tr>";
   $n=0;
    while($arr=mysql_fetch_array($sel))
   {
   $i=$arr['img'];
   
    if($n%1==0)
	{
	echo "<tr'><tr>
	      ";
	}
   echo 
   "<td height='280' width='240' align='center'><img src='product_image/$i' height='200' width='200'></td>
 <b>
 <td align='center'>".$arr['product_name'].
   "</td><td align='center'>".$arr['price'].
  "
   
   </td>";
  
  $n++;

   }
   	  echo "</tr></table>
       </form>";
	?>

<?php }  ?>

        </div>
    </div>

    <div class="teamcontainer">
        <div class="team">
            Web Developer: Hein Htet, Yangon, Myanmar. 9/10/2023 Unknown Restruarnt.com.
        </div>
    </div>
</body>
</html>