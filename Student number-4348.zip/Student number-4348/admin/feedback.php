<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="code/bootstrap.min.css">
    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/6041b3011b.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="menucontainer">
        <div class="logocontainer">
            <img src="img/brand logo.png" alt="" width="160%" >
        </div>
        <div class="menubox">
            <a href="home.php" class="menu">Home</a>
            <a href="add_product.php" class="menu">Add Product</a>
            <a href="view_product.php" class="menu">View Product</a>
        </div>
        <div class="menubar"><i class="fa-solid fa-bars"></i></div>
    </div><!--End Header-->

	<div class="feedContainer" >
		<div class="feedBox" >
    	<h2 align="center"> View Feedback Message</h2>
       <table  style="border-color:#000000;border-style: solid; background-color:#000000; margin:40px auto;" width="1000px" >
					
					<tr><th width="100px" height="50px">ID:</th>					
						<th width="100px" height="50px">Name:</th>
						<th width="100px" height="50px">Email:</th>
						<th width="100px" height="50px">Phone:</th>	
						<th width="100px" height="50px">Message:</th>						
					 </tr>	
					 <?php
					 error_reporting(1);
					 include("connection.php");
						$sel=mysql_query("select * from feedback ");
						while($row=mysql_fetch_array($sel))
							{		
									$id=$row['feed_id'];					
									$name=$row['name'];
									$email=$row['email'];
									$phone=$row['phone'];
									$mesg=$row['mesg'];
									
						?>
					 <tr>
						
						<td width="100px" height="50px"><?php echo $id; ?></td>
						<td width="100px" height="50px"><?php echo $name; ?></td>
						<td width="100px" height="50px"><?php echo $email; ?></td>
						<td width="100px" height="50px"><?php echo $phone; ?></td>
						<td width="100px" height="50px"><?php echo $mesg; ?></td>
						
						
												
					  </tr>			
					<?php				  
							}	
					?>
					</table>
		</div>
	</div>
<?php }  ?>


    <div class="teamcontainer">
        <div class="team">
            Web Developer: Hein Htet, Yangon, Myanmar. 9/10/2023 Unknown Restruarnt.com.
        </div>
    </div>
</body>
</html>