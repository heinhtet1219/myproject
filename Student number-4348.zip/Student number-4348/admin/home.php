<?php
session_start();
if($_SESSION['sid']=="")
{
header('location:index.php');
}
else{
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="code/bootstrap.min.css">
    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/6041b3011b.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="menucontainer">
        <div class="logocontainer">
            <img src="img/brand logo.png" alt="" width="160%" >
        </div>
        <div class="menubox">
            <a href="home.php" class="menu">Home</a>
            <a href="add_product.php" class="menu">Add Product</a>
            <a href="view_product.php" class="menu">View Product</a>
        </div>
        <div class="menubar"><i class="fa-solid fa-bars"></i></div>
    </div><!--End Header-->

    <div class="homeContainer">
        <div class="loginBox">
            <div class="loginHeader">Welcome Admin</div>
			<ul class="sb_menu">
				<li class="menulist" ><a href="feedback.php" class="item" >View feedback</a></li>
				<li class="menulist"><a href="view_order.php" class="item">View order</a></li>
				<li class="menulist"><a href="logout.php" class="item">Log Out</a></li>
			</ul>
        </div>
        </div>
    </div>



    <div class="teamcontainer">
        <div class="team">
            Web Developer: Hein Htet, Yangon, Myanmar. 9/10/2023 Unknown Restruarnt.com.
        </div>
    </div>
    <?php }  ?>
</body>
</html>