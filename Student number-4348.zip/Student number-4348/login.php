<?php
session_start();
error_reporting(1);
$i=$_REQUEST['buy_pro'];
include("connection.php");
if(isset($_POST['log']))
{ if($_POST['id']=="" || $_POST['pwd']=="")
{ $err="fill your id and password first"; }
else 
{$d=mysql_query("select * from register where email='{$_POST['id']}' ");
$row=mysql_fetch_object($d);
$fid=$row->email;
$fpass=$row->password; 
if($fid==$_POST['id'] && $fpass==$_POST['pwd'])
{$_SESSION['sid']=$_POST['id'];
//echo"<script>location:href='order.php?img=$i'</script>";
header("location:order.php?buy_pro=$i"); 
}
else {$err=" your password is not"; }}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="code/bootstrap.min.css">
    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/6041b3011b.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="menucontainer">
        <div class="logocontainer">
            <img src="img/brand logo.png" alt="" width="160%" >
        </div>
        <div class="menubox">
            <a href="index.php" class="menu">Home</a>
            <a href="register.php" class="menu">Register</a>
            <a href="feedback.php" class="menu">Feedback</a>
        </div>
        <div class="menubar"><i class="fa-solid fa-bars"></i></div>
    </div><!--End Header-->

    <div class="loginContainer">
        <div class="loginBox">
            <div class="loginHeader">LOGIN</div>
            <form action="" method="post">
                <label for="email">Email</label><br>
                <input type="email" name="id" id="email"><br>
                <label for="pass">Password</label><br>
                <input type="password" name="pwd" id="pass"><br>
                <input type="checkbox">
                <span>Remember me</span>
                <input class="btn btn-primary" type="submit" value="Login" name="log" id="sub">
            </form>
        </div>
    </div>



    <div class="teamcontainer">
        <div class="team">
            Web Developer: Hein Htet, Yangon, Myanmar. 9/10/2023 Unknown Restruarnt.com.
        </div>
    </div>
</body>
</html>