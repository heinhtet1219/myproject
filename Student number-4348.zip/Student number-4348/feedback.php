<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>feedback</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="code/bootstrap.min.css">
    <script src="code/jquery.min.js"></script>
    <script src="code/popper.min.js"></script>
    <script src="code/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/6041b3011b.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="slidercontainer">
        <div class="brandcontainer">
            <div class="brand">
                Unknown Restruarnt<br>
                Address: Unknown<br>
                Phone: Unknown
            </div>
        </div>
        <div class="slider">
            <div id="demo" class="carousel slide slider1" data-ride="carousel">
                <ul class="carousel-indicators">
                  <li data-target="#demo" data-slide-to="0" class="active"></li>
                  <li data-target="#demo" data-slide-to="1"></li>
                  <li data-target="#demo" data-slide-to="2"></li>
                </ul>
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img src="img/1.jpg" width="100%" height="100%">   
                  </div>
                  <div class="carousel-item">
                    <img src="img/2.jpg" width="100%" height="100%">  
                  </div>
                  <div class="carousel-item">
                    <img src="img/3.jpg" width="100%" height="100%">   
                  </div>
                </div>
                <a class="carousel-control-prev" href="#demo" data-slide="prev">
                  <span class="carousel-control-prev-icon"></span>
                </a>
                <a class="carousel-control-next" href="#demo" data-slide="next">
                  <span class="carousel-control-next-icon"></span>
                </a>
              </div>
        </div>
    </div><!--End Slider-->


    <div class="menucontainer">
        <div class="logocontainer">
            <img src="img/brand logo.png" alt="" width="160%" >
        </div>
        <div class="menubox">
            <a href="index.php" class="menu">Home</a>
            <a href="register.php" class="menu">Register</a>
            <a href="feedback.php" class="menu">Feedback</a>
        </div>
        <div class="menubar"><i class="fa-solid fa-bars"></i></div>
    </div><!--End Header-->


    <div class="maincontainer">
        <div class="left">
            <div class="menuheader">
                Categories
            </div>
            <div class="menuitem">
                <ul class="rul">
                    <li class="menulist"><a href="#" class="item">Food</a></li>
                    <li class="menulist"><a href="#" class="item">Beer</a></li>
                    <li class="menulist"><a href="#" class="item">Wine</a></li>
                    <li class="menulist"><a href="#" class="item">Whiskey</a></li>
                    <li class="menulist"><a href="#" class="item">Vodka</a></li>
                    <li class="menulist"><a href="#" class="item">Cocktail</a></li>
                </ul>
            </div>
        </div>
        <div class="right">
        <?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$phone=$_POST['t3'];
$mesg=$_POST['t4'];
if(mysql_query("insert into feedback(name,email,phone,mesg) values('$name','$email','$phone','$mesg')"))
{$er="<font color='red' size='+1'> Message sent successfully</font>"; }
}

?>
        <div class="fbContainer" >
    	<h2>Feedback Information</h2>
            <div id="contact_form" class="col_2">
                <h3 style="margin: 20px;" >Send a message</h3>
                <table>
                <form method="post" name="contact" action="#">
                    <div class="col_4">
                        <tr>
                        <td><label for="phone">Name:</label></td>
                        <td><input type="text" id="t1" name="t1" class="required input_field" /></td>
                        </tr>
                    </div>
                    <div class="col_4 no_margin_right">
                        <tr>
                        <td><label for="email">Email:</label></td>
                        <td><input type="email" id="t2" name="t2" class="validate-email required input_field" /></td>
                        </tr>
                    </div>
                    <div class="clear h10"></div>
                     <div class="col_4 no_margin_right">
                        <tr>
                        <td><label for="phone">Phone:</label></td>
                        <td><input type="text" id="t3" name="t3" class="required input_field" /></td>
                        </tr>
                    </div>
                    
                    <div class="clear"></div>
                    <tr>
                    <td><label for="text">Message:</label></td>
                    <td> <textarea id="t4" name="t4" rows="0" cols="0" class="required"></textarea></td>
                    </tr>
                    <tr>
                    <td colspan="2"> <input type="submit" name="sub"  id="sub" value="Send" class="submit_button" /></td>
                    </tr>
                </form>
                </table>
				<h2><?php echo $er;?></h2>
            </div>
        </div> 
        </div>
    </div><!--End Body-->


    <div class="footer">
        <div class="timecontainer">
            <div class="timeheader">Opening Hours</div>
            <div class="name">Unknown Restruarnt</div>
            <ul class="time">
                <li>MON to THU - 9AM to 8PM</li> 
                <li>FRI - 9AM to 11PM</li>
                <li>SAT - 9AM to 11PM</li>
                <li>SUN - 9AM to 11PM</li>
            </ul>
        </div>
        <div class="informcontainer">
            <div class="timeheader">Contact Information</div>
            <div class="name">No.79, 9th street, Lanmadaw Township, Yangon, Myanmar.</div>
            <ul class="time">
                <li>+95999999999</li> 
                <li>+95999999999</li>
                <li>+95999999999</li>
                <li>+95999999999</li>
            </ul>
        </div>
        <div class="socialcontainer">
            <div class="timeheader">Social With Us</div>
            <div class="social">
                <a href="#"><i class="fa-brands fa-facebook"></i></a>
                <a href="#"><i class="fa-brands fa-youtube"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
            </div>
        </div>
    </div><!--End footer-->


    <div class="teamcontainer">
        <div class="team">
            Web Developer: Hein Htet, Yangon, Myanmar. 9/10/2023 Unknown Restruarnt.com.
        </div>
    </div>
</body>
</html>